Proxy for plexile arcade
